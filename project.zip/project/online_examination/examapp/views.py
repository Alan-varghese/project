from django.shortcuts import render,redirect,HttpResponse
from examapp.models import *
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth import logout
# Create your views here.
def index(request):
    return render(request,'index.html')



